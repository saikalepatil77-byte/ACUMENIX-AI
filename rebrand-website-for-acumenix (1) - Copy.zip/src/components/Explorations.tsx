import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);
// ScrollTrigger is used via gsap.fromTo's scrollTrigger config

const GALLERY_ITEMS = [
  {
    id: 1,
    title: 'Motion Study #01',
    category: 'Motion Design',
    col: 'left',
    height: 280,
    rotation: '-3deg',
    gradient: 'linear-gradient(135deg, rgba(137,170,204,0.2) 0%, rgba(78,133,191,0.1) 100%)',
    color: '#89AACC',
  },
  {
    id: 2,
    title: 'Visual Concept #02',
    category: 'Art Direction',
    col: 'right',
    height: 200,
    rotation: '2deg',
    gradient: 'linear-gradient(135deg, rgba(78,133,191,0.2) 0%, rgba(107,154,184,0.1) 100%)',
    color: '#4E85BF',
  },
  {
    id: 3,
    title: 'Type Experiment #03',
    category: 'Typography',
    col: 'left',
    height: 200,
    rotation: '2deg',
    gradient: 'linear-gradient(135deg, rgba(107,154,184,0.18) 0%, rgba(137,170,204,0.08) 100%)',
    color: '#6B9AB8',
  },
  {
    id: 4,
    title: 'Interface Study #04',
    category: 'UI Design',
    col: 'right',
    height: 300,
    rotation: '-2deg',
    gradient: 'linear-gradient(135deg, rgba(90,143,173,0.2) 0%, rgba(78,133,191,0.08) 100%)',
    color: '#5A8FAD',
  },
  {
    id: 5,
    title: 'Creative Code #05',
    category: 'Generative',
    col: 'left',
    height: 220,
    rotation: '-1deg',
    gradient: 'linear-gradient(135deg, rgba(137,170,204,0.15) 0%, rgba(90,143,173,0.1) 100%)',
    color: '#89AACC',
  },
  {
    id: 6,
    title: 'Brand Play #06',
    category: 'Branding',
    col: 'right',
    height: 240,
    rotation: '3deg',
    gradient: 'linear-gradient(135deg, rgba(78,133,191,0.18) 0%, rgba(137,170,204,0.08) 100%)',
    color: '#4E85BF',
  },
];

function GalleryCard({ item, onClick }: { item: typeof GALLERY_ITEMS[0]; onClick: () => void }) {
  return (
    <motion.div
      className="relative rounded-2xl overflow-hidden cursor-zoom-in group mb-4"
      style={{
        height: item.height,
        background: item.gradient,
        border: '1px solid hsl(0 0% 12%)',
        rotate: item.rotation,
      }}
      whileHover={{ scale: 1.02, rotate: '0deg' }}
      transition={{ duration: 0.3 }}
      onClick={onClick}
    >
      {/* Halftone */}
      <div className="absolute inset-0 halftone-overlay opacity-30 pointer-events-none" />

      {/* Content */}
      <div className="absolute inset-0 flex flex-col justify-between p-5">
        <div
          className="text-5xl font-display italic opacity-20"
          style={{ color: item.color }}
        >
          {String(item.id).padStart(2, '0')}
        </div>
        <div>
          <p
            className="text-xs tracking-widest uppercase mb-1"
            style={{ color: 'hsl(0 0% 40%)' }}
          >
            {item.category}
          </p>
          <p
            className="text-sm font-medium"
            style={{ color: 'hsl(0 0% 80%)' }}
          >
            {item.title}
          </p>
        </div>
      </div>

      {/* Hover overlay */}
      <div
        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        style={{ background: 'rgba(137,170,204,0.05)' }}
      />
    </motion.div>
  );
}

export default function Explorations() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const leftColRef = useRef<HTMLDivElement>(null);
  const rightColRef = useRef<HTMLDivElement>(null);
  const [lightboxItem, setLightboxItem] = useState<typeof GALLERY_ITEMS[0] | null>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const leftCol = leftColRef.current;
    const rightCol = rightColRef.current;
    if (!section || !leftCol || !rightCol) return;

    const mm = gsap.matchMedia();

    mm.add('(min-width: 768px)', () => {
      // Parallax on columns
      gsap.fromTo(
        leftCol,
        { y: 0 },
        {
          y: -120,
          ease: 'none',
          scrollTrigger: {
            trigger: section,
            start: 'top bottom',
            end: 'bottom top',
            scrub: 1.5,
          },
        }
      );

      gsap.fromTo(
        rightCol,
        { y: 0 },
        {
          y: 120,
          ease: 'none',
          scrollTrigger: {
            trigger: section,
            start: 'top bottom',
            end: 'bottom top',
            scrub: 1.5,
          },
        }
      );
    });

    return () => {
      mm.revert();
    };
  }, []);

  const leftItems = GALLERY_ITEMS.filter(item => item.col === 'left');
  const rightItems = GALLERY_ITEMS.filter(item => item.col === 'right');

  return (
    <>
      <section
        id="explorations"
        ref={sectionRef}
        className="py-24 md:py-32 overflow-hidden"
        style={{ background: 'hsl(0 0% 4%)', minHeight: '150vh' }}
      >
        <div className="max-w-[1200px] mx-auto px-6 md:px-10 lg:px-16">
          {/* Header */}
          <motion.div
            className="mb-20 text-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          >
            <p
              className="text-xs tracking-[0.3em] uppercase mb-4"
              style={{ color: 'hsl(0 0% 53%)' }}
            >
              Visual Playground
            </p>
            <h2
              className="text-4xl md:text-5xl font-semibold mb-4 leading-tight"
              style={{ color: 'hsl(0 0% 96%)' }}
            >
              Visual{' '}
              <span className="font-display italic">playground</span>
            </h2>
            <p
              className="text-base max-w-xl mx-auto leading-relaxed"
              style={{ color: 'hsl(0 0% 53%)' }}
            >
              Experiments, visual concepts, motion studies, and creative technology explorations.
            </p>
          </motion.div>

          {/* Two-column gallery */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Left column */}
            <div ref={leftColRef} className="space-y-4">
              {leftItems.map(item => (
                <GalleryCard
                  key={item.id}
                  item={item}
                  onClick={() => setLightboxItem(item)}
                />
              ))}
            </div>

            {/* Right column */}
            <div ref={rightColRef} className="space-y-4 md:mt-16">
              {rightItems.map(item => (
                <GalleryCard
                  key={item.id}
                  item={item}
                  onClick={() => setLightboxItem(item)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Lightbox */}
      <AnimatePresence>
        {lightboxItem && (
          <motion.div
            className="fixed inset-0 z-[200] flex items-center justify-center p-6"
            style={{ background: 'rgba(0,0,0,0.9)', backdropFilter: 'blur(12px)' }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setLightboxItem(null)}
          >
            <motion.div
              className="relative max-w-2xl w-full rounded-2xl overflow-hidden"
              style={{
                background: lightboxItem.gradient,
                border: '1px solid rgba(137,170,204,0.2)',
                minHeight: '400px',
              }}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.3 }}
              onClick={e => e.stopPropagation()}
            >
              <div className="halftone-overlay absolute inset-0 opacity-30" />
              <div className="relative p-10 flex flex-col justify-between min-h-[400px]">
                <div className="flex justify-between items-start">
                  <div
                    className="text-8xl font-display italic opacity-20"
                    style={{ color: lightboxItem.color }}
                  >
                    {String(lightboxItem.id).padStart(2, '0')}
                  </div>
                  <button
                    onClick={() => setLightboxItem(null)}
                    className="w-10 h-10 rounded-full flex items-center justify-center text-sm transition-colors"
                    style={{
                      background: 'rgba(255,255,255,0.1)',
                      color: 'hsl(0 0% 96%)',
                    }}
                    aria-label="Close lightbox"
                  >
                    ✕
                  </button>
                </div>
                <div>
                  <p
                    className="text-xs tracking-widest uppercase mb-2"
                    style={{ color: 'hsl(0 0% 53%)' }}
                  >
                    {lightboxItem.category}
                  </p>
                  <h3
                    className="text-2xl md:text-3xl font-semibold"
                    style={{ color: 'hsl(0 0% 96%)' }}
                  >
                    {lightboxItem.title}
                  </h3>
                  <p className="text-sm mt-3" style={{ color: 'hsl(0 0% 53%)' }}>
                    A creative exploration by ACUMENIX — pushing the boundaries of visual design and technology.
                  </p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
