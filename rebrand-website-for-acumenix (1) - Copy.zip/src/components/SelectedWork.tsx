import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const PROJECTS = [
  {
    id: 1,
    title: 'Digital Experience',
    category: 'UX / Web',
    description: 'Immersive digital interfaces crafted for engagement and conversion.',
    color: '#89AACC',
    span: 'lg:col-span-2 lg:row-span-2',
    height: 'h-[300px] lg:h-full',
  },
  {
    id: 2,
    title: 'Automation Systems',
    category: 'Tech / Automation',
    description: 'Custom automation pipelines that eliminate friction and scale operations.',
    color: '#4E85BF',
    span: 'lg:col-span-1',
    height: 'h-[220px]',
  },
  {
    id: 3,
    title: 'Brand & Creative',
    category: 'Design / Identity',
    description: 'Visual identities that communicate personality, vision, and value.',
    color: '#6B9AB8',
    span: 'lg:col-span-1',
    height: 'h-[220px]',
  },
  {
    id: 4,
    title: 'Web Development',
    category: 'Dev / Engineering',
    description: 'High-performance web products built with modern technology stacks.',
    color: '#5A8FAD',
    span: 'lg:col-span-2',
    height: 'h-[220px]',
  },
];

const GRADIENTS = [
  'linear-gradient(135deg, rgba(137,170,204,0.15) 0%, rgba(78,133,191,0.08) 100%)',
  'linear-gradient(135deg, rgba(78,133,191,0.15) 0%, rgba(107,154,184,0.08) 100%)',
  'linear-gradient(135deg, rgba(107,154,184,0.12) 0%, rgba(137,170,204,0.08) 100%)',
  'linear-gradient(135deg, rgba(90,143,173,0.15) 0%, rgba(78,133,191,0.08) 100%)',
];

function ProjectCard({ project, index, gradient }: {
  project: typeof PROJECTS[0];
  index: number;
  gradient: string;
}) {
  return (
    <motion.div
      className={`relative rounded-2xl overflow-hidden cursor-pointer group ${project.span} ${project.height}`}
      style={{
        background: gradient,
        border: '1px solid hsl(0 0% 12%)',
      }}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.7, delay: index * 0.1, ease: [0.16, 1, 0.3, 1] }}
      whileHover={{ scale: 1.01 }}
    >
      {/* Halftone overlay */}
      <div
        className="absolute inset-0 opacity-40 halftone-overlay pointer-events-none"
      />

      {/* Gradient border on hover */}
      <div
        className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
        style={{
          background: 'transparent',
          boxShadow: `inset 0 0 0 1px rgba(137,170,204,0.4)`,
        }}
      />

      {/* Backdrop blur content */}
      <div className="absolute inset-0 flex flex-col justify-end p-6 md:p-8">
        {/* Category pill */}
        <div
          className="inline-flex self-start mb-3 px-3 py-1 rounded-full text-xs tracking-widest uppercase"
          style={{
            background: 'rgba(255,255,255,0.06)',
            border: '1px solid rgba(255,255,255,0.1)',
            color: 'hsl(0 0% 53%)',
            backdropFilter: 'blur(8px)',
          }}
        >
          {project.category}
        </div>

        <h3
          className="text-xl md:text-2xl font-semibold mb-2 transition-all duration-300 group-hover:translate-x-1"
          style={{ color: 'hsl(0 0% 96%)' }}
        >
          {project.title}
        </h3>
        <p
          className="text-sm leading-relaxed"
          style={{ color: 'hsl(0 0% 53%)' }}
        >
          {project.description}
        </p>

        {/* Arrow */}
        <div
          className="mt-4 w-8 h-8 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 translate-x-2 group-hover:translate-x-0"
          style={{ background: 'linear-gradient(90deg, #89AACC 0%, #4E85BF 100%)' }}
        >
          <span className="text-xs text-white">↗</span>
        </div>
      </div>

      {/* Large number */}
      <div
        className="absolute top-6 right-6 text-6xl md:text-8xl font-display italic opacity-5 select-none"
        style={{ color: project.color }}
      >
        {String(index + 1).padStart(2, '0')}
      </div>
    </motion.div>
  );
}

export default function SelectedWork() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const inView = useInView(sectionRef, { once: true, margin: '-100px' });

  return (
    <section
      id="work"
      ref={sectionRef}
      className="py-24 md:py-32"
      style={{ background: 'hsl(0 0% 4%)' }}
    >
      <div className="max-w-[1200px] mx-auto px-6 md:px-10 lg:px-16">
        {/* Section header */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        >
          <p
            className="text-xs tracking-[0.3em] uppercase mb-4"
            style={{ color: 'hsl(0 0% 53%)' }}
          >
            Selected Work
          </p>
          <h2
            className="text-4xl md:text-5xl font-semibold mb-4 leading-tight"
            style={{ color: 'hsl(0 0% 96%)' }}
          >
            Featured{' '}
            <span className="font-display italic">projects</span>
          </h2>
          <p
            className="text-base max-w-xl leading-relaxed"
            style={{ color: 'hsl(0 0% 53%)' }}
          >
            A selection of digital experiences, creative systems, and technology projects built by ACUMENIX.
          </p>
        </motion.div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 lg:grid-rows-2" style={{ minHeight: '600px' }}>
          {PROJECTS.map((project, i) => (
            <ProjectCard
              key={project.id}
              project={project}
              index={i}
              gradient={GRADIENTS[i]}
            />
          ))}
        </div>

        {/* View all CTA */}
        <motion.div
          className="mt-12 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.4 }}
        >
          <button
            onClick={() => {
              const el = document.getElementById('work');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="inline-flex items-center gap-2 text-sm transition-colors duration-200"
            style={{ color: 'hsl(0 0% 53%)' }}
            onMouseEnter={e => {
              (e.currentTarget as HTMLElement).style.color = 'hsl(0 0% 96%)';
            }}
            onMouseLeave={e => {
              (e.currentTarget as HTMLElement).style.color = 'hsl(0 0% 53%)';
            }}
          >
            View all work
            <span
              className="w-6 h-px inline-block transition-all duration-300 group-hover:w-10"
              style={{ background: 'linear-gradient(90deg, #89AACC 0%, #4E85BF 100%)' }}
            />
          </button>
        </motion.div>
      </div>
    </section>
  );
}
