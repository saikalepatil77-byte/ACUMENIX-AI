import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';

interface LoadingScreenProps {
  onComplete: () => void;
}

const WORDS = ['Design', 'Create', 'Innovate'];

export default function LoadingScreen({ onComplete }: LoadingScreenProps) {
  const [counter, setCounter] = useState(0);
  const [wordIndex, setWordIndex] = useState(0);
  const [done, setDone] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const wordIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const duration = 2700;
    const steps = 100;
    const stepTime = duration / steps;

    intervalRef.current = setInterval(() => {
      setCounter(prev => {
        if (prev >= 100) {
          if (intervalRef.current) clearInterval(intervalRef.current);
          return 100;
        }
        return prev + 1;
      });
    }, stepTime);

    wordIntervalRef.current = setInterval(() => {
      setWordIndex(prev => (prev + 1) % WORDS.length);
    }, 700);

    const timer = setTimeout(() => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (wordIntervalRef.current) clearInterval(wordIntervalRef.current);
      setCounter(100);
      setTimeout(() => {
        setDone(true);
        setTimeout(onComplete, 500);
      }, 400);
    }, duration + 400);

    return () => {
      clearInterval(intervalRef.current!);
      clearInterval(wordIntervalRef.current!);
      clearTimeout(timer);
    };
  }, [onComplete]);

  const counterStr = String(counter).padStart(3, '0');

  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          className="fixed inset-0 z-[9999] flex flex-col"
          style={{ background: 'hsl(0 0% 4%)' }}
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.6, ease: 'easeInOut' } }}
        >
          {/* Top left branding */}
          <div className="absolute top-8 left-8 md:top-10 md:left-12">
            <span
              className="text-xs tracking-[0.3em] uppercase font-body"
              style={{ color: 'hsl(0 0% 53%)' }}
            >
              ACUMENIX — DIGITAL STUDIO
            </span>
          </div>

          {/* Center word animation */}
          <div className="flex flex-1 items-center justify-center">
            <div className="relative overflow-hidden">
              <AnimatePresence mode="wait">
                <motion.span
                  key={wordIndex}
                  className="block text-4xl md:text-6xl lg:text-7xl font-display italic"
                  style={{ color: 'hsl(0 0% 96%)' }}
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: -20, opacity: 0 }}
                  transition={{ duration: 0.35, ease: 'easeInOut' }}
                >
                  {WORDS[wordIndex]}
                </motion.span>
              </AnimatePresence>
            </div>
          </div>

          {/* Bottom bar */}
          <div className="px-8 md:px-12 pb-10 space-y-4">
            {/* Progress bar */}
            <div
              className="w-full h-[3px] rounded-full overflow-hidden"
              style={{ background: 'hsl(0 0% 12%)' }}
            >
              <motion.div
                className="h-full accent-gradient"
                style={{ width: `${counter}%` }}
                transition={{ duration: 0.05 }}
              />
            </div>

            {/* Counter */}
            <div className="flex justify-between items-center">
              <span
                className="text-xs tracking-[0.2em] uppercase font-body"
                style={{ color: 'hsl(0 0% 53%)' }}
              >
                Loading
              </span>
              <span
                className="text-sm font-body tabular-nums"
                style={{ color: 'hsl(0 0% 96%)' }}
              >
                {counterStr}
              </span>
            </div>
          </div>

          {/* Subtle center glow */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: 'radial-gradient(ellipse 60% 40% at 50% 50%, rgba(78,133,191,0.06) 0%, transparent 70%)'
            }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
