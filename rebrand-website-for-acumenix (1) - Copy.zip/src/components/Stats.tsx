import { motion } from 'framer-motion';

const STATS = [
  {
    label: 'Digital First',
    sublabel: 'Everything we build starts with the digital experience in mind.',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="3" width="20" height="14" rx="2" />
        <path d="M8 21h8M12 17v4" />
      </svg>
    ),
  },
  {
    label: 'Creative × Technology',
    sublabel: 'Where artistic vision and technical mastery converge to build the extraordinary.',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="3" />
        <path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 19.07a10 10 0 0 1 0-14.14" />
        <path d="M22 12a10 10 0 0 1-10 10M2 12a10 10 0 0 1 10-10" />
      </svg>
    ),
  },
  {
    label: 'Built For Growth',
    sublabel: 'Every solution is architected to evolve, scale, and compound value over time.',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="22 7 13.5 15.5 8.5 10.5 2 17" />
        <polyline points="16 7 22 7 22 13" />
      </svg>
    ),
  },
];

export default function Stats() {
  return (
    <section
      id="stats"
      className="py-20 md:py-24"
      style={{ background: 'hsl(0 0% 8%)', borderTop: '1px solid hsl(0 0% 12%)', borderBottom: '1px solid hsl(0 0% 12%)' }}
    >
      <div className="max-w-[1200px] mx-auto px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-4">
          {STATS.map((stat, i) => (
            <motion.div
              key={stat.label}
              className="relative text-center md:text-left p-6 group"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-30px' }}
              transition={{ duration: 0.7, delay: i * 0.15, ease: [0.16, 1, 0.3, 1] }}
            >
              {/* Divider on desktop */}
              {i > 0 && (
                <div
                  className="hidden md:block absolute left-0 top-1/2 -translate-y-1/2 w-px h-16"
                  style={{ background: 'hsl(0 0% 12%)' }}
                />
              )}

              {/* Icon */}
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center mb-4 mx-auto md:mx-0"
                style={{
                  background: 'rgba(137,170,204,0.08)',
                  color: '#89AACC',
                }}
              >
                {stat.icon}
              </div>

              {/* Label */}
              <h3
                className="text-lg md:text-xl font-semibold mb-2"
                style={{ color: 'hsl(0 0% 96%)' }}
              >
                {stat.label}
              </h3>

              {/* Sublabel */}
              <p
                className="text-sm leading-relaxed"
                style={{ color: 'hsl(0 0% 53%)' }}
              >
                {stat.sublabel}
              </p>

              {/* Accent dot */}
              <div
                className="mt-4 w-6 h-0.5 accent-gradient mx-auto md:mx-0 rounded-full opacity-60 group-hover:opacity-100 group-hover:w-10 transition-all duration-300"
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
