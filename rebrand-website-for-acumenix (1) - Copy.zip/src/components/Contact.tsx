import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface FormData {
  name: string;
  email: string;
  company: string;
  phone: string;
  projectType: string;
  budget: string;
  timeline: string;
  requirements: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  projectType?: string;
  requirements?: string;
}

const PROJECT_TYPES = [
  'Web Development',
  'Automation',
  'Video Creation',
  'Video Editing',
  'Graphic Design',
  'Branding',
  'Digital Experience',
  'Other',
];

const BUDGET_OPTIONS = [
  'Under ₹10,000',
  '₹10,000 – ₹25,000',
  '₹25,000 – ₹50,000',
  '₹50,000 – ₹1,00,000',
  '₹1,00,000+',
  'Not decided yet',
];

const TIMELINE_OPTIONS = [
  'ASAP',
  '1–2 weeks',
  '1 month',
  '1–3 months',
  'Flexible',
];

const EMPTY_FORM: FormData = {
  name: '',
  email: '',
  company: '',
  phone: '',
  projectType: '',
  budget: '',
  timeline: '',
  requirements: '',
};

function validateEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function InputField({
  id,
  label,
  type = 'text',
  value,
  onChange,
  placeholder,
  required,
  error,
}: {
  id: string;
  label: string;
  type?: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  required?: boolean;
  error?: string;
}) {
  return (
    <div className="space-y-1.5">
      <label
        htmlFor={id}
        className="block text-sm font-medium"
        style={{ color: 'hsl(0 0% 72%)' }}
      >
        {label}
        {required && (
          <span className="ml-1" style={{ color: '#89AACC' }} aria-hidden="true">*</span>
        )}
      </label>
      <input
        id={id}
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        aria-required={required}
        aria-describedby={error ? `${id}-error` : undefined}
        aria-invalid={!!error}
        className="w-full px-4 py-3 rounded-xl text-sm transition-all duration-200 outline-none"
        style={{
          background: 'hsl(0 0% 8%)',
          border: error ? '1px solid rgba(239,68,68,0.5)' : '1px solid hsl(0 0% 14%)',
          color: 'hsl(0 0% 96%)',
        }}
        onFocus={e => {
          e.currentTarget.style.borderColor = error ? 'rgba(239,68,68,0.7)' : 'rgba(137,170,204,0.4)';
          e.currentTarget.style.boxShadow = '0 0 0 2px rgba(137,170,204,0.08)';
        }}
        onBlur={e => {
          e.currentTarget.style.borderColor = error ? 'rgba(239,68,68,0.5)' : 'hsl(0 0% 14%)';
          e.currentTarget.style.boxShadow = 'none';
        }}
      />
      {error && (
        <p id={`${id}-error`} className="text-xs" style={{ color: 'rgb(239,68,68)' }} role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

function SelectField({
  id,
  label,
  value,
  onChange,
  options,
  placeholder,
  required,
  error,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: string[];
  placeholder?: string;
  required?: boolean;
  error?: string;
}) {
  return (
    <div className="space-y-1.5">
      <label
        htmlFor={id}
        className="block text-sm font-medium"
        style={{ color: 'hsl(0 0% 72%)' }}
      >
        {label}
        {required && (
          <span className="ml-1" style={{ color: '#89AACC' }} aria-hidden="true">*</span>
        )}
      </label>
      <select
        id={id}
        value={value}
        onChange={e => onChange(e.target.value)}
        required={required}
        aria-required={required}
        aria-describedby={error ? `${id}-error` : undefined}
        aria-invalid={!!error}
        className="w-full px-4 py-3 rounded-xl text-sm transition-all duration-200 outline-none appearance-none"
        style={{
          background: 'hsl(0 0% 8%)',
          border: error ? '1px solid rgba(239,68,68,0.5)' : '1px solid hsl(0 0% 14%)',
          color: value ? 'hsl(0 0% 96%)' : 'hsl(0 0% 40%)',
          cursor: 'pointer',
        }}
        onFocus={e => {
          e.currentTarget.style.borderColor = error ? 'rgba(239,68,68,0.7)' : 'rgba(137,170,204,0.4)';
          e.currentTarget.style.boxShadow = '0 0 0 2px rgba(137,170,204,0.08)';
        }}
        onBlur={e => {
          e.currentTarget.style.borderColor = error ? 'rgba(239,68,68,0.5)' : 'hsl(0 0% 14%)';
          e.currentTarget.style.boxShadow = 'none';
        }}
      >
        {placeholder && (
          <option value="" disabled style={{ background: 'hsl(0 0% 8%)', color: 'hsl(0 0% 40%)' }}>
            {placeholder}
          </option>
        )}
        {options.map(opt => (
          <option key={opt} value={opt} style={{ background: 'hsl(0 0% 8%)', color: 'hsl(0 0% 96%)' }}>
            {opt}
          </option>
        ))}
      </select>
      {error && (
        <p id={`${id}-error`} className="text-xs" style={{ color: 'rgb(239,68,68)' }} role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

export default function Contact() {
  const [form, setForm] = useState<FormData>(EMPTY_FORM);
  const [errors, setErrors] = useState<FormErrors>({});
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const formRef = useRef<HTMLFormElement>(null);

  const update = (field: keyof FormData) => (value: string) => {
    setForm(prev => ({ ...prev, [field]: value }));
    if (errors[field as keyof FormErrors]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const validate = (): boolean => {
    const newErrors: FormErrors = {};
    if (!form.name.trim()) newErrors.name = 'Full name is required.';
    if (!form.email.trim()) newErrors.email = 'Email address is required.';
    else if (!validateEmail(form.email)) newErrors.email = 'Please enter a valid email address.';
    if (!form.projectType) newErrors.projectType = 'Please select a project type.';
    if (!form.requirements.trim()) newErrors.requirements = 'Please describe your project requirements.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setStatus('submitting');
    setErrorMessage('');

    const endpoint = import.meta.env.VITE_FORM_ENDPOINT;

    const payload = {
      name: form.name,
      email: form.email,
      company: form.company,
      phone: form.phone,
      projectType: form.projectType,
      budget: form.budget,
      timeline: form.timeline,
      requirements: form.requirements,
    };

    if (endpoint) {
      // Use configured endpoint
      try {
        const response = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });

        if (response.ok) {
          setStatus('success');
          setForm(EMPTY_FORM);
        } else {
          throw new Error(`Server responded with ${response.status}`);
        }
      } catch {
        setStatus('error');
        setErrorMessage(
          'Something went wrong. Please try again or email us directly at acumenix.ai@gmail.com.'
        );
      }
    } else {
      // Fallback: open email client
      const subject = encodeURIComponent(`Project Enquiry — ${form.projectType || 'General'}`);
      const body = encodeURIComponent(
        `Full Name: ${form.name}\n` +
        `Email: ${form.email}\n` +
        `Company: ${form.company || 'N/A'}\n` +
        `Phone: ${form.phone || 'N/A'}\n` +
        `Project Type: ${form.projectType}\n` +
        `Budget: ${form.budget || 'N/A'}\n` +
        `Timeline: ${form.timeline || 'N/A'}\n\n` +
        `Requirements:\n${form.requirements}`
      );
      window.open(`mailto:acumenix.ai@gmail.com?subject=${subject}&body=${body}`, '_blank');
      setStatus('success');
      setForm(EMPTY_FORM);
    }
  };

  return (
    <section
      id="contact"
      className="py-24 md:py-32"
      style={{ background: 'hsl(0 0% 6%)' }}
    >
      <div className="max-w-[1200px] mx-auto px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_1.6fr] gap-16 lg:gap-24 items-start">
          {/* Left — Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          >
            <p
              className="text-xs tracking-[0.3em] uppercase mb-4"
              style={{ color: 'hsl(0 0% 53%)' }}
            >
              Get In Touch
            </p>
            <h2
              className="text-4xl md:text-5xl font-semibold mb-5 leading-tight"
              style={{ color: 'hsl(0 0% 96%)' }}
            >
              Let's build something{' '}
              <span className="font-display italic">great.</span>
            </h2>
            <p
              className="text-base leading-relaxed mb-8"
              style={{ color: 'hsl(0 0% 53%)' }}
            >
              Tell us about your project and the ACUMENIX team will get back to you.
            </p>

            {/* Contact details */}
            <div className="space-y-4">
              <div>
                <p className="text-xs tracking-widest uppercase mb-1" style={{ color: 'hsl(0 0% 40%)' }}>
                  Email
                </p>
                <a
                  href="mailto:acumenix.ai@gmail.com"
                  className="text-sm transition-colors duration-200"
                  style={{ color: 'hsl(0 0% 80%)' }}
                  onMouseEnter={e => (e.currentTarget.style.color = '#89AACC')}
                  onMouseLeave={e => (e.currentTarget.style.color = 'hsl(0 0% 80%)')}
                >
                  acumenix.ai@gmail.com
                </a>
              </div>

              <div>
                <p className="text-xs tracking-widest uppercase mb-1" style={{ color: 'hsl(0 0% 40%)' }}>
                  Instagram
                </p>
                <a
                  href="https://www.instagram.com/acumenix.ai/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm flex items-center gap-2 transition-colors duration-200 group"
                  style={{ color: 'hsl(0 0% 80%)' }}
                  onMouseEnter={e => (e.currentTarget.style.color = '#89AACC')}
                  onMouseLeave={e => (e.currentTarget.style.color = 'hsl(0 0% 80%)')}
                >
                  <svg
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                  </svg>
                  @acumenix.ai
                </a>
              </div>

              {/* Available indicator */}
              <div className="pt-4 flex items-center gap-2">
                <div className="relative w-2 h-2">
                  <div
                    className="absolute inset-0 rounded-full animate-ping opacity-60"
                    style={{ background: '#4ade80' }}
                  />
                  <div
                    className="relative w-2 h-2 rounded-full"
                    style={{ background: '#4ade80' }}
                  />
                </div>
                <span className="text-sm" style={{ color: 'hsl(0 0% 53%)' }}>
                  Available for projects
                </span>
              </div>
            </div>
          </motion.div>

          {/* Right — Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          >
            <AnimatePresence mode="wait">
              {status === 'success' ? (
                <motion.div
                  key="success"
                  className="flex flex-col items-center justify-center text-center py-20 px-8 rounded-2xl"
                  style={{
                    background: 'hsl(0 0% 8%)',
                    border: '1px solid rgba(137,170,204,0.2)',
                    minHeight: '400px',
                  }}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.4 }}
                >
                  {/* Success icon */}
                  <div
                    className="w-16 h-16 rounded-full flex items-center justify-center mb-6"
                    style={{ background: 'rgba(137,170,204,0.1)' }}
                  >
                    <svg
                      width="28"
                      height="28"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#89AACC"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </div>

                  <h3
                    className="text-2xl font-semibold mb-3"
                    style={{ color: 'hsl(0 0% 96%)' }}
                  >
                    Thanks — your project enquiry has been received.
                  </h3>
                  <p
                    className="text-base mb-8"
                    style={{ color: 'hsl(0 0% 53%)' }}
                  >
                    ACUMENIX will get back to you soon.
                  </p>
                  <button
                    onClick={() => setStatus('idle')}
                    className="px-6 py-3 rounded-full text-sm font-medium transition-all duration-200 accent-gradient-border"
                    style={{
                      color: 'hsl(0 0% 96%)',
                      background: 'rgba(255,255,255,0.04)',
                    }}
                    onMouseEnter={e => {
                      (e.currentTarget as HTMLElement).style.background = 'rgba(137,170,204,0.1)';
                    }}
                    onMouseLeave={e => {
                      (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.04)';
                    }}
                  >
                    Send another enquiry
                  </button>
                </motion.div>
              ) : (
                <motion.form
                  key="form"
                  ref={formRef}
                  onSubmit={handleSubmit}
                  noValidate
                  className="rounded-2xl p-6 md:p-8 space-y-6"
                  style={{
                    background: 'hsl(0 0% 8%)',
                    border: '1px solid hsl(0 0% 12%)',
                  }}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  {/* Required fields */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <InputField
                      id="name"
                      label="Full Name"
                      value={form.name}
                      onChange={update('name')}
                      placeholder="Your full name"
                      required
                      error={errors.name}
                    />
                    <InputField
                      id="email"
                      label="Email Address"
                      type="email"
                      value={form.email}
                      onChange={update('email')}
                      placeholder="you@example.com"
                      required
                      error={errors.email}
                    />
                  </div>

                  <SelectField
                    id="projectType"
                    label="Project Type"
                    value={form.projectType}
                    onChange={update('projectType')}
                    options={PROJECT_TYPES}
                    placeholder="Select project type..."
                    required
                    error={errors.projectType}
                  />

                  {/* Optional fields */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <InputField
                      id="company"
                      label="Company / Brand Name"
                      value={form.company}
                      onChange={update('company')}
                      placeholder="Optional"
                    />
                    <InputField
                      id="phone"
                      label="Phone Number"
                      type="tel"
                      value={form.phone}
                      onChange={update('phone')}
                      placeholder="Optional"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <SelectField
                      id="budget"
                      label="Budget Range"
                      value={form.budget}
                      onChange={update('budget')}
                      options={BUDGET_OPTIONS}
                      placeholder="Select budget..."
                    />
                    <SelectField
                      id="timeline"
                      label="Preferred Timeline"
                      value={form.timeline}
                      onChange={update('timeline')}
                      options={TIMELINE_OPTIONS}
                      placeholder="Select timeline..."
                    />
                  </div>

                  {/* Requirements textarea */}
                  <div className="space-y-1.5">
                    <label
                      htmlFor="requirements"
                      className="block text-sm font-medium"
                      style={{ color: 'hsl(0 0% 72%)' }}
                    >
                      Project Requirements
                      <span className="ml-1" style={{ color: '#89AACC' }} aria-hidden="true">*</span>
                    </label>
                    <textarea
                      id="requirements"
                      value={form.requirements}
                      onChange={e => update('requirements')(e.target.value)}
                      placeholder="Tell us what you need, your goals, references, features, or anything else we should know..."
                      required
                      aria-required="true"
                      aria-describedby={errors.requirements ? 'requirements-error' : undefined}
                      aria-invalid={!!errors.requirements}
                      rows={6}
                      className="w-full px-4 py-3 rounded-xl text-sm transition-all duration-200 outline-none resize-y"
                      style={{
                        background: 'hsl(0 0% 8%)',
                        border: errors.requirements ? '1px solid rgba(239,68,68,0.5)' : '1px solid hsl(0 0% 14%)',
                        color: 'hsl(0 0% 96%)',
                        minHeight: '120px',
                        maxHeight: '300px',
                      }}
                      onFocus={e => {
                        e.currentTarget.style.borderColor = errors.requirements
                          ? 'rgba(239,68,68,0.7)'
                          : 'rgba(137,170,204,0.4)';
                        e.currentTarget.style.boxShadow = '0 0 0 2px rgba(137,170,204,0.08)';
                      }}
                      onBlur={e => {
                        e.currentTarget.style.borderColor = errors.requirements
                          ? 'rgba(239,68,68,0.5)'
                          : 'hsl(0 0% 14%)';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                    />
                    {errors.requirements && (
                      <p
                        id="requirements-error"
                        className="text-xs"
                        style={{ color: 'rgb(239,68,68)' }}
                        role="alert"
                      >
                        {errors.requirements}
                      </p>
                    )}
                  </div>

                  {/* Error message */}
                  <AnimatePresence>
                    {status === 'error' && (
                      <motion.p
                        className="text-sm px-4 py-3 rounded-xl"
                        style={{
                          background: 'rgba(239,68,68,0.08)',
                          border: '1px solid rgba(239,68,68,0.2)',
                          color: 'rgb(248,113,113)',
                        }}
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        role="alert"
                      >
                        {errorMessage}
                      </motion.p>
                    )}
                  </AnimatePresence>

                  {/* Note about endpoint */}
                  {!import.meta.env.VITE_FORM_ENDPOINT && (
                    <p className="text-xs" style={{ color: 'hsl(0 0% 35%)' }}>
                      Submitting will open your email client with the enquiry pre-filled, addressed to acumenix.ai@gmail.com.
                    </p>
                  )}

                  {/* Submit button */}
                  <button
                    type="submit"
                    disabled={status === 'submitting'}
                    className="w-full py-4 rounded-xl text-sm font-medium transition-all duration-200 flex items-center justify-center gap-2"
                    style={{
                      background: status === 'submitting'
                        ? 'rgba(137,170,204,0.4)'
                        : 'linear-gradient(90deg, #89AACC 0%, #4E85BF 100%)',
                      color: 'white',
                      cursor: status === 'submitting' ? 'not-allowed' : 'pointer',
                    }}
                    onMouseEnter={e => {
                      if (status !== 'submitting') {
                        (e.currentTarget as HTMLElement).style.boxShadow = '0 8px 32px rgba(78,133,191,0.3)';
                        (e.currentTarget as HTMLElement).style.transform = 'translateY(-1px)';
                      }
                    }}
                    onMouseLeave={e => {
                      (e.currentTarget as HTMLElement).style.boxShadow = 'none';
                      (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
                    }}
                    aria-live="polite"
                  >
                    {status === 'submitting' ? (
                      <>
                        <svg
                          className="animate-spin"
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          aria-hidden="true"
                        >
                          <circle cx="12" cy="12" r="10" strokeOpacity="0.25" />
                          <path d="M12 2a10 10 0 0 1 10 10" />
                        </svg>
                        Sending...
                      </>
                    ) : (
                      'Send Enquiry ↗'
                    )}
                  </button>
                </motion.form>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
