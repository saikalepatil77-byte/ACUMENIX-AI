import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

const NAV_LINKS = [
  { label: 'Home', href: '#home' },
  { label: 'Work', href: '#work' },
  { label: 'Services', href: '#services' },
  { label: 'About', href: '#about' },
  { label: 'Contact', href: '#contact' },
];

function scrollToSection(href: string) {
  const id = href.replace('#', '');
  const el = document.getElementById(id);
  if (el) {
    el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 60);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close menu on resize
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) setMenuOpen(false);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <>
      <motion.nav
        className="fixed top-4 left-1/2 z-[100] -translate-x-1/2"
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
        style={{ width: 'calc(100% - 2rem)', maxWidth: '900px' }}
      >
        <div
          className="flex items-center justify-between px-4 md:px-6 py-3 rounded-full transition-all duration-300"
          style={{
            background: scrolled
              ? 'rgba(10,10,10,0.95)'
              : 'rgba(10,10,10,0.80)',
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)',
            border: '1px solid hsl(0 0% 12%)',
            boxShadow: scrolled
              ? '0 8px 32px rgba(0,0,0,0.6)'
              : '0 4px 16px rgba(0,0,0,0.4)',
          }}
        >
          {/* Logo */}
          <button
            onClick={() => scrollToSection('#home')}
            className="flex items-center gap-2 flex-shrink-0"
            aria-label="ACUMENIX — Go to home"
          >
            <img
              src="/acumenix-logo.png"
              alt="ACUMENIX"
              className="h-7 md:h-8 w-auto object-contain"
              style={{ maxWidth: '140px' }}
            />
          </button>

          {/* Desktop nav links */}
          <div className="hidden md:flex items-center gap-1">
            {NAV_LINKS.map(link => (
              <button
                key={link.label}
                onClick={() => scrollToSection(link.href)}
                className="px-3 py-1.5 text-sm transition-colors duration-200 rounded-full hover:text-white"
                style={{ color: 'hsl(0 0% 53%)' }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLElement).style.color = 'hsl(0 0% 96%)';
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLElement).style.color = 'hsl(0 0% 53%)';
                }}
              >
                {link.label}
              </button>
            ))}
          </div>

          {/* CTA + Mobile menu toggle */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => scrollToSection('#contact')}
              className="hidden md:flex items-center gap-1 px-4 py-2 text-sm rounded-full font-medium transition-all duration-200 accent-gradient-border"
              style={{
                color: 'hsl(0 0% 96%)',
                background: 'rgba(255,255,255,0.04)',
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLElement).style.background = 'rgba(137,170,204,0.1)';
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.04)';
              }}
            >
              Let's Talk ↗
            </button>

            {/* Mobile hamburger */}
            <button
              className="md:hidden flex flex-col gap-1.5 p-1"
              onClick={() => setMenuOpen(prev => !prev)}
              aria-label={menuOpen ? 'Close menu' : 'Open menu'}
            >
              <span
                className="block w-5 h-px transition-all duration-300"
                style={{
                  background: 'hsl(0 0% 96%)',
                  transform: menuOpen ? 'rotate(45deg) translate(2px, 3px)' : 'none',
                }}
              />
              <span
                className="block w-5 h-px transition-all duration-300"
                style={{
                  background: 'hsl(0 0% 96%)',
                  opacity: menuOpen ? 0 : 1,
                }}
              />
              <span
                className="block w-5 h-px transition-all duration-300"
                style={{
                  background: 'hsl(0 0% 96%)',
                  transform: menuOpen ? 'rotate(-45deg) translate(2px, -3px)' : 'none',
                }}
              />
            </button>
          </div>
        </div>
      </motion.nav>

      {/* Mobile menu dropdown */}
      {menuOpen && (
        <motion.div
          className="fixed top-20 left-4 right-4 z-[99] rounded-2xl overflow-hidden"
          style={{
            background: 'rgba(10,10,10,0.98)',
            backdropFilter: 'blur(20px)',
            border: '1px solid hsl(0 0% 12%)',
          }}
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          <div className="p-4 space-y-1">
            {NAV_LINKS.map(link => (
              <button
                key={link.label}
                onClick={() => {
                  scrollToSection(link.href);
                  setMenuOpen(false);
                }}
                className="w-full text-left px-4 py-3 text-base rounded-xl transition-colors duration-150"
                style={{ color: 'hsl(0 0% 72%)' }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.05)';
                  (e.currentTarget as HTMLElement).style.color = 'hsl(0 0% 96%)';
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLElement).style.background = 'transparent';
                  (e.currentTarget as HTMLElement).style.color = 'hsl(0 0% 72%)';
                }}
              >
                {link.label}
              </button>
            ))}
            <div className="pt-2 pb-1 px-4">
              <button
                onClick={() => {
                  scrollToSection('#contact');
                  setMenuOpen(false);
                }}
                className="w-full py-3 text-sm rounded-full font-medium accent-gradient text-white"
              >
                Let's Talk ↗
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </>
  );
}
