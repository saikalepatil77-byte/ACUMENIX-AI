import { motion } from 'framer-motion';

const PILLARS = [
  {
    title: 'Design-Led',
    description: 'Every decision starts with design thinking — beautiful, purposeful, and human-centred.',
  },
  {
    title: 'Tech-Powered',
    description: 'Modern technology stacks, automation, and intelligent systems drive every project forward.',
  },
  {
    title: 'Outcome-Driven',
    description: 'We measure success by the impact we create — not just the work we produce.',
  },
];

export default function About() {
  return (
    <section
      id="about"
      className="py-24 md:py-32"
      style={{ background: 'hsl(0 0% 4%)' }}
    >
      <div className="max-w-[1200px] mx-auto px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-start">
          {/* Left column */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          >
            <p
              className="text-xs tracking-[0.3em] uppercase mb-4"
              style={{ color: 'hsl(0 0% 53%)' }}
            >
              About ACUMENIX
            </p>
            <h2
              className="text-4xl md:text-5xl font-semibold mb-6 leading-tight"
              style={{ color: 'hsl(0 0% 96%)' }}
            >
              A creative{' '}
              <span className="font-display italic">technology</span>{' '}
              company
            </h2>

            <div className="space-y-4" style={{ color: 'hsl(0 0% 60%)' }}>
              <p className="text-base leading-relaxed">
                ACUMENIX is a creative technology company focused on building modern digital experiences through design, development, automation, and creative production.
              </p>
              <p className="text-base leading-relaxed">
                We operate at the intersection of art and engineering — combining strategic thinking with technical excellence and creative craft to deliver work that is genuinely impactful.
              </p>
              <p className="text-base leading-relaxed">
                Whether you need a premium web presence, a complex automation system, a visual identity, or a cinematic video — we bring the same rigour, craft, and ambition to everything we build.
              </p>
            </div>

            <div className="mt-10 flex flex-wrap gap-4">
              <button
                onClick={() => {
                  const el = document.getElementById('contact');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-6 py-3 rounded-full text-sm font-medium transition-all duration-200 accent-gradient-border"
                style={{
                  color: 'hsl(0 0% 96%)',
                  background: 'rgba(255,255,255,0.04)',
                }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLElement).style.background = 'rgba(137,170,204,0.1)';
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.04)';
                }}
              >
                Work With Us ↗
              </button>
              <a
                href="mailto:acumenix.ai@gmail.com"
                className="px-6 py-3 rounded-full text-sm font-medium transition-colors duration-200 inline-block"
                style={{ color: 'hsl(0 0% 53%)' }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLElement).style.color = 'hsl(0 0% 96%)';
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLElement).style.color = 'hsl(0 0% 53%)';
                }}
              >
                acumenix.ai@gmail.com
              </a>
            </div>
          </motion.div>

          {/* Right column — pillars */}
          <div className="space-y-4">
            {PILLARS.map((pillar, i) => (
              <motion.div
                key={pillar.title}
                className="p-6 rounded-2xl"
                style={{
                  background: 'hsl(0 0% 8%)',
                  border: '1px solid hsl(0 0% 12%)',
                }}
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: '-30px' }}
                transition={{ duration: 0.7, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
                whileHover={{ borderColor: 'rgba(137,170,204,0.3)' }}
              >
                <div className="flex items-start gap-4">
                  <div
                    className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0 accent-gradient"
                  />
                  <div>
                    <h3
                      className="text-base font-semibold mb-2"
                      style={{ color: 'hsl(0 0% 96%)' }}
                    >
                      {pillar.title}
                    </h3>
                    <p
                      className="text-sm leading-relaxed"
                      style={{ color: 'hsl(0 0% 53%)' }}
                    >
                      {pillar.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}

            {/* Domain / Brand */}
            <motion.div
              className="p-6 rounded-2xl"
              style={{
                background: 'linear-gradient(135deg, rgba(137,170,204,0.08) 0%, rgba(78,133,191,0.04) 100%)',
                border: '1px solid rgba(137,170,204,0.15)',
              }}
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
            >
              <p
                className="text-xs tracking-widest uppercase mb-1"
                style={{ color: 'hsl(0 0% 53%)' }}
              >
                Brand
              </p>
              <p
                className="text-lg font-semibold"
                style={{ color: 'hsl(0 0% 96%)' }}
              >
                ACUMENIX.AI
              </p>
              <p
                className="text-sm mt-1"
                style={{ color: 'hsl(0 0% 53%)' }}
              >
                acumenix.ai
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
