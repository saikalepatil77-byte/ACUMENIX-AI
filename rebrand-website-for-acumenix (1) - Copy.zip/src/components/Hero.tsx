import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { gsap } from 'gsap';
import HLSVideo from './HLSVideo';

const HLS_SRC = 'https://stream.mux.com/Aa02T7oM1wH5Mk5EEVDYhbZ1ChcdhRsS2m1NYyx4Ua1g.m3u8';

const ROTATING_LINES = [
  'A Creative Technology Studio.',
  'A Digital Experience Studio.',
  'A Web & Automation Studio.',
  'A Future-Focused Creative Company.',
];

function scrollToSection(id: string) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

export default function Hero() {
  const [lineIndex, setLineIndex] = useState(0);
  const nameRef = useRef<HTMLHeadingElement>(null);
  const blurRefs = useRef<HTMLElement[]>([]);

  // GSAP hero animations
  useEffect(() => {
    const ctx = gsap.context(() => {
      // Name reveal
      if (nameRef.current) {
        gsap.fromTo(
          nameRef.current,
          { opacity: 0, y: 50 },
          {
            opacity: 1,
            y: 0,
            duration: 1.2,
            delay: 0.1,
            ease: 'power3.out',
          }
        );
      }

      // Blur-in elements
      if (blurRefs.current.length) {
        gsap.fromTo(
          blurRefs.current.filter(Boolean),
          { opacity: 0, filter: 'blur(10px)', y: 20 },
          {
            opacity: 1,
            filter: 'blur(0px)',
            y: 0,
            duration: 1,
            stagger: 0.1,
            delay: 0.3,
            ease: 'power3.out',
          }
        );
      }
    });

    return () => ctx.revert();
  }, []);

  // Rotating lines
  useEffect(() => {
    const timer = setInterval(() => {
      setLineIndex(prev => (prev + 1) % ROTATING_LINES.length);
    }, 2000);
    return () => clearInterval(timer);
  }, []);

  const addBlurRef = (el: HTMLElement | null, index: number) => {
    if (el) blurRefs.current[index] = el;
  };

  return (
    <section
      id="home"
      className="relative w-full overflow-hidden"
      style={{ height: '100svh', minHeight: '600px' }}
    >
      {/* Cinematic video background */}
      <div className="absolute inset-0 w-full h-full overflow-hidden">
        <HLSVideo
          src={HLS_SRC}
          className="absolute top-1/2 left-1/2 min-w-full min-h-full object-cover"
          style={{ transform: 'translate(-50%, -50%)' }}
          autoPlay
          muted
          loop
          playsInline
        />
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-black/20" />
        {/* Bottom fade */}
        <div
          className="absolute bottom-0 left-0 right-0 h-48"
          style={{ background: 'linear-gradient(to top, hsl(0 0% 4%) 0%, transparent 100%)' }}
        />
      </div>

      {/* Hero content */}
      <div className="relative z-10 flex flex-col justify-end h-full pb-20 px-6 md:px-10 lg:px-16">
        {/* Eyebrow */}
        <p
          ref={el => addBlurRef(el as HTMLElement, 0)}
          className="blur-in text-xs md:text-sm tracking-[0.3em] uppercase mb-6"
          style={{ color: 'hsl(0 0% 53%)' }}
        >
          CREATIVE TECHNOLOGY STUDIO
        </p>

        {/* Main heading */}
        <h1
          ref={nameRef}
          className="name-reveal font-display italic leading-[0.9] tracking-tight mb-6"
          style={{
            fontSize: 'clamp(4rem, 12vw, 10rem)',
            color: 'hsl(0 0% 96%)',
          }}
        >
          ACUMENIX
        </h1>

        {/* Subheading */}
        <p
          ref={el => addBlurRef(el as HTMLElement, 1)}
          className="blur-in text-lg md:text-xl mb-3 font-light"
          style={{ color: 'hsl(0 0% 72%)' }}
        >
          Where creativity meets technology.
        </p>

        {/* Rotating line */}
        <div
          ref={el => addBlurRef(el as HTMLElement, 2)}
          className="blur-in h-7 overflow-hidden mb-8"
        >
          <AnimatePresence mode="wait">
            <motion.p
              key={lineIndex}
              className="text-sm md:text-base"
              style={{ color: 'hsl(0 0% 53%)' }}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              transition={{ duration: 0.4, ease: 'easeInOut' }}
            >
              {ROTATING_LINES[lineIndex]}
            </motion.p>
          </AnimatePresence>
        </div>

        {/* Description */}
        <p
          ref={el => addBlurRef(el as HTMLElement, 3)}
          className="blur-in text-sm md:text-base max-w-lg mb-10 leading-relaxed"
          style={{ color: 'hsl(0 0% 53%)' }}
        >
          ACUMENIX creates premium digital experiences through web development, automation, creative design, video, and modern technology.
        </p>

        {/* Buttons */}
        <div
          ref={el => addBlurRef(el as HTMLElement, 4)}
          className="blur-in flex flex-wrap gap-4"
        >
          <button
            onClick={() => scrollToSection('work')}
            className="px-6 py-3 rounded-full text-sm font-medium transition-all duration-200"
            style={{
              background: 'hsl(0 0% 96%)',
              color: 'hsl(0 0% 4%)',
            }}
            onMouseEnter={e => {
              (e.currentTarget as HTMLElement).style.background = 'hsl(0 0% 100%)';
              (e.currentTarget as HTMLElement).style.transform = 'scale(1.02)';
            }}
            onMouseLeave={e => {
              (e.currentTarget as HTMLElement).style.background = 'hsl(0 0% 96%)';
              (e.currentTarget as HTMLElement).style.transform = 'scale(1)';
            }}
          >
            Explore Our Work
          </button>

          <button
            onClick={() => scrollToSection('contact')}
            className="px-6 py-3 rounded-full text-sm font-medium transition-all duration-200 accent-gradient-border"
            style={{
              color: 'hsl(0 0% 96%)',
              background: 'rgba(255,255,255,0.04)',
            }}
            onMouseEnter={e => {
              (e.currentTarget as HTMLElement).style.background = 'rgba(137,170,204,0.1)';
              (e.currentTarget as HTMLElement).style.transform = 'scale(1.02)';
            }}
            onMouseLeave={e => {
              (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.04)';
              (e.currentTarget as HTMLElement).style.transform = 'scale(1)';
            }}
          >
            Work With Us ↗
          </button>
        </div>
      </div>

      {/* Subtle center glow */}
      <div
        className="absolute inset-0 pointer-events-none z-[1]"
        style={{
          background: 'radial-gradient(ellipse 70% 50% at 50% 60%, rgba(78,133,191,0.05) 0%, transparent 70%)'
        }}
      />
    </section>
  );
}
