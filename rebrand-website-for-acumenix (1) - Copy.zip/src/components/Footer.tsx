import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import HLSVideo from './HLSVideo';

const HLS_SRC = 'https://stream.mux.com/Aa02T7oM1wH5Mk5EEVDYhbZ1ChcdhRsS2m1NYyx4Ua1g.m3u8';

const MARQUEE_TEXT = 'BUILDING THE FUTURE • ';
const MARQUEE_REPEAT = 10;

const FOOTER_NAV = [
  { label: 'Home', href: '#home' },
  { label: 'Work', href: '#work' },
  { label: 'Services', href: '#services' },
  { label: 'About', href: '#about' },
  { label: 'Contact', href: '#contact' },
];

function scrollToSection(href: string) {
  const id = href.replace('#', '');
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

export default function Footer() {
  const marqueeRef = useRef<HTMLDivElement>(null);
  const marqueeInnerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const inner = marqueeInnerRef.current;
    if (!inner) return;

    const tween = gsap.to(inner, {
      xPercent: -50,
      duration: 40,
      ease: 'none',
      repeat: -1,
    });

    return () => {
      tween.kill();
    };
  }, []);

  return (
    <footer
      id="footer"
      className="relative overflow-hidden"
      style={{ background: 'hsl(0 0% 4%)' }}
    >
      {/* Cinematic video background (flipped) */}
      <div
        className="absolute inset-0 w-full h-full overflow-hidden"
        aria-hidden="true"
        style={{ transform: 'scaleY(-1)' }}
      >
        <HLSVideo
          src={HLS_SRC}
          className="absolute top-1/2 left-1/2 min-w-full min-h-full object-cover"
          style={{ transform: 'translate(-50%, -50%)' }}
          autoPlay
          muted
          loop
          playsInline
        />
        <div className="absolute inset-0 bg-black/60" />
      </div>

      {/* Content container — sits above flipped video */}
      <div className="relative z-10">
        {/* Marquee */}
        <div
          ref={marqueeRef}
          className="overflow-hidden border-y py-4"
          style={{ borderColor: 'hsl(0 0% 12%)' }}
          aria-hidden="true"
        >
          <div ref={marqueeInnerRef} className="flex whitespace-nowrap">
            {Array.from({ length: MARQUEE_REPEAT * 2 }).map((_, i) => (
              <span
                key={i}
                className="text-sm tracking-[0.3em] uppercase mx-4 flex-shrink-0"
                style={{ color: 'hsl(0 0% 30%)' }}
              >
                {MARQUEE_TEXT}
              </span>
            ))}
          </div>
        </div>

        {/* Main footer content */}
        <div className="max-w-[1200px] mx-auto px-6 md:px-10 lg:px-16 py-20">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-16">
            {/* Brand column */}
            <div className="lg:col-span-1">
              <img
                src="/acumenix-logo.png"
                alt="ACUMENIX"
                className="h-10 w-auto object-contain mb-6"
                style={{ maxWidth: '180px' }}
              />
              <p
                className="text-sm leading-relaxed mb-6 max-w-xs"
                style={{ color: 'hsl(0 0% 40%)' }}
              >
                Creative technology. Digital experiences. Built for the future.
              </p>

              {/* Available indicator */}
              <div className="flex items-center gap-2 mb-6">
                <div className="relative w-2 h-2">
                  <div
                    className="absolute inset-0 rounded-full animate-ping opacity-60"
                    style={{ background: '#4ade80' }}
                  />
                  <div
                    className="relative w-2 h-2 rounded-full"
                    style={{ background: '#4ade80' }}
                  />
                </div>
                <span className="text-xs" style={{ color: 'hsl(0 0% 53%)' }}>
                  Available for projects
                </span>
              </div>

              {/* Email CTA */}
              <a
                href="mailto:acumenix.ai@gmail.com"
                className="inline-flex items-center gap-2 text-sm font-medium transition-colors duration-200"
                style={{ color: 'hsl(0 0% 72%)' }}
                onMouseEnter={e => (e.currentTarget.style.color = '#89AACC')}
                onMouseLeave={e => (e.currentTarget.style.color = 'hsl(0 0% 72%)')}
                aria-label="Email ACUMENIX at acumenix.ai@gmail.com"
              >
                Email ACUMENIX ↗
              </a>
            </div>

            {/* Nav links */}
            <div>
              <p
                className="text-xs tracking-[0.25em] uppercase mb-6"
                style={{ color: 'hsl(0 0% 40%)' }}
              >
                Navigation
              </p>
              <nav aria-label="Footer navigation">
                <ul className="space-y-3">
                  {FOOTER_NAV.map(link => (
                    <li key={link.label}>
                      <button
                        onClick={() => scrollToSection(link.href)}
                        className="text-sm transition-colors duration-200"
                        style={{ color: 'hsl(0 0% 53%)' }}
                        onMouseEnter={e => (e.currentTarget.style.color = 'hsl(0 0% 96%)')}
                        onMouseLeave={e => (e.currentTarget.style.color = 'hsl(0 0% 53%)')}
                      >
                        {link.label}
                      </button>
                    </li>
                  ))}
                </ul>
              </nav>
            </div>

            {/* Contact info */}
            <div>
              <p
                className="text-xs tracking-[0.25em] uppercase mb-6"
                style={{ color: 'hsl(0 0% 40%)' }}
              >
                Contact
              </p>
              <div className="space-y-4">
                <div>
                  <p className="text-xs mb-1" style={{ color: 'hsl(0 0% 35%)' }}>
                    Email
                  </p>
                  <a
                    href="mailto:acumenix.ai@gmail.com"
                    className="text-sm transition-colors duration-200"
                    style={{ color: 'hsl(0 0% 60%)' }}
                    onMouseEnter={e => (e.currentTarget.style.color = '#89AACC')}
                    onMouseLeave={e => (e.currentTarget.style.color = 'hsl(0 0% 60%)')}
                  >
                    acumenix.ai@gmail.com
                  </a>
                </div>

                <div>
                  <p className="text-xs mb-1" style={{ color: 'hsl(0 0% 35%)' }}>
                    Instagram
                  </p>
                  <a
                    href="https://www.instagram.com/acumenix.ai/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm flex items-center gap-2 transition-colors duration-200"
                    style={{ color: 'hsl(0 0% 60%)' }}
                    onMouseEnter={e => (e.currentTarget.style.color = '#89AACC')}
                    onMouseLeave={e => (e.currentTarget.style.color = 'hsl(0 0% 60%)')}
                    aria-label="Follow ACUMENIX on Instagram"
                  >
                    <svg
                      width="14"
                      height="14"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.8"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                      <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                    </svg>
                    @acumenix.ai
                  </a>
                </div>

                <div>
                  <p className="text-xs mb-1" style={{ color: 'hsl(0 0% 35%)' }}>
                    Domain
                  </p>
                  <span className="text-sm" style={{ color: 'hsl(0 0% 60%)' }}>
                    acumenix.ai
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div
          className="max-w-[1200px] mx-auto px-6 md:px-10 lg:px-16 py-6"
          style={{ borderTop: '1px solid hsl(0 0% 10%)' }}
        >
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-xs" style={{ color: 'hsl(0 0% 30%)' }}>
              © {new Date().getFullYear()} ACUMENIX. All rights reserved.
            </p>
            <p className="text-xs" style={{ color: 'hsl(0 0% 25%)' }}>
              ACUMENIX.AI — Creative Technology Studio
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
