import { useRef, useState } from 'react';
import { motion } from 'framer-motion';

const ARTICLES = [
  {
    id: 1,
    title: 'The Future of Web Interfaces',
    excerpt: 'How motion, interaction, and AI are redefining the standards of digital experience design.',
    date: 'Jan 2025',
    readTime: '5 min read',
    tag: 'Design',
    color: '#89AACC',
  },
  {
    id: 2,
    title: 'Automation Without Compromise',
    excerpt: 'Building intelligent workflows that scale operations without sacrificing quality or control.',
    date: 'Dec 2024',
    readTime: '7 min read',
    tag: 'Technology',
    color: '#4E85BF',
  },
  {
    id: 3,
    title: 'Brand Identity in the Digital Age',
    excerpt: 'Why consistent visual identity across all digital touchpoints matters more than ever.',
    date: 'Nov 2024',
    readTime: '4 min read',
    tag: 'Branding',
    color: '#6B9AB8',
  },
  {
    id: 4,
    title: 'Video as a Business Asset',
    excerpt: 'Cinematic production techniques adapted for brand storytelling and digital campaigns.',
    date: 'Oct 2024',
    readTime: '6 min read',
    tag: 'Creative',
    color: '#5A8FAD',
  },
];

export default function Journal() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [activeId, setActiveId] = useState<number | null>(null);

  return (
    <section
      id="journal"
      className="py-24 md:py-32 overflow-hidden"
      style={{ background: 'hsl(0 0% 6%)' }}
    >
      <div className="max-w-[1200px] mx-auto px-6 md:px-10 lg:px-16 mb-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        >
          <p
            className="text-xs tracking-[0.3em] uppercase mb-4"
            style={{ color: 'hsl(0 0% 53%)' }}
          >
            Journal
          </p>
          <h2
            className="text-4xl md:text-5xl font-semibold mb-4 leading-tight"
            style={{ color: 'hsl(0 0% 96%)' }}
          >
            Recent{' '}
            <span className="font-display italic">thoughts</span>
          </h2>
          <p
            className="text-base max-w-xl leading-relaxed"
            style={{ color: 'hsl(0 0% 53%)' }}
          >
            Ideas, insights, experiments, and perspectives from technology, design, automation, and digital creativity.
          </p>
        </motion.div>
      </div>

      {/* Horizontal scroll pills */}
      <div
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto pb-4 px-6 md:px-10 lg:px-16"
        style={{
          scrollbarWidth: 'none',
          msOverflowStyle: 'none',
        }}
      >
        {ARTICLES.map((article, i) => (
          <motion.article
            key={article.id}
            className="flex-shrink-0 w-[300px] md:w-[360px] rounded-2xl p-6 cursor-pointer group transition-all duration-300"
            style={{
              background: activeId === article.id ? 'hsl(0 0% 10%)' : 'hsl(0 0% 8%)',
              border: activeId === article.id
                ? '1px solid rgba(137,170,204,0.3)'
                : '1px solid hsl(0 0% 12%)',
            }}
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.6, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
            whileHover={{ y: -2 }}
            onClick={() => setActiveId(prev => prev === article.id ? null : article.id)}
            onMouseEnter={e => {
              (e.currentTarget as HTMLElement).style.borderColor = 'rgba(137,170,204,0.25)';
            }}
            onMouseLeave={e => {
              if (activeId !== article.id) {
                (e.currentTarget as HTMLElement).style.borderColor = 'hsl(0 0% 12%)';
              }
            }}
          >
            {/* Top row */}
            <div className="flex items-center justify-between mb-4">
              <span
                className="text-xs px-3 py-1 rounded-full"
                style={{
                  background: `rgba(${article.id === 1 ? '137,170,204' : article.id === 2 ? '78,133,191' : '107,154,184'},0.1)`,
                  color: article.color,
                  border: `1px solid rgba(${article.id === 1 ? '137,170,204' : article.id === 2 ? '78,133,191' : '107,154,184'},0.2)`,
                }}
              >
                {article.tag}
              </span>
              <div className="flex items-center gap-2 text-xs" style={{ color: 'hsl(0 0% 40%)' }}>
                <span>{article.date}</span>
                <span>·</span>
                <span>{article.readTime}</span>
              </div>
            </div>

            {/* Article image placeholder */}
            <div
              className="w-full h-36 rounded-xl mb-4 flex items-center justify-center overflow-hidden"
              style={{
                background: `linear-gradient(135deg, rgba(${article.id === 1 ? '137,170,204' : article.id === 2 ? '78,133,191' : article.id === 3 ? '107,154,184' : '90,143,173'},0.12) 0%, rgba(10,10,10,0.5) 100%)`,
              }}
            >
              <span
                className="text-4xl font-display italic opacity-30"
                style={{ color: article.color }}
              >
                {String(article.id).padStart(2, '0')}
              </span>
            </div>

            <h3
              className="text-base font-semibold mb-2 group-hover:translate-x-0.5 transition-transform duration-200"
              style={{ color: 'hsl(0 0% 96%)' }}
            >
              {article.title}
            </h3>
            <p
              className="text-sm leading-relaxed"
              style={{ color: 'hsl(0 0% 53%)' }}
            >
              {article.excerpt}
            </p>

            <div className="mt-4 flex items-center gap-2 text-xs" style={{ color: article.color }}>
              <span>Read more</span>
              <span>→</span>
            </div>
          </motion.article>
        ))}
      </div>
    </section>
  );
}
